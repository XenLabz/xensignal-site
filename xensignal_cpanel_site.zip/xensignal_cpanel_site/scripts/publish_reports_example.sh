#!/usr/bin/env bash
set -euo pipefail

# Example publisher for Mac/Linux.
# Replace these values before use. Do not put real passwords in this file.
CPANEL_USER="YOUR_CPANEL_USERNAME"
CPANEL_HOST="xenlabz.com"
REMOTE_PATH="/home/YOUR_CPANEL_USERNAME/public_html/xensignal/reports"

LOCAL_SHADOW_SUMMARY="${1:-Production/reports/historical_shadow/shadow_replay_summary.json}"
LOCAL_OPTIMIZER_STATE="${2:-Production/state/xensignal_profit_optimizer.json}"

if [[ ! -f "$LOCAL_SHADOW_SUMMARY" ]]; then
  echo "Missing shadow summary: $LOCAL_SHADOW_SUMMARY"
  exit 1
fi

if [[ ! -f "$LOCAL_OPTIMIZER_STATE" ]]; then
  echo "Missing optimizer state: $LOCAL_OPTIMIZER_STATE"
  exit 1
fi

scp "$LOCAL_SHADOW_SUMMARY" "${CPANEL_USER}@${CPANEL_HOST}:${REMOTE_PATH}/latest-shadow-summary.json"
scp "$LOCAL_OPTIMIZER_STATE" "${CPANEL_USER}@${CPANEL_HOST}:${REMOTE_PATH}/latest-optimizer-state.json"

echo "Published XenSignal reports to ${CPANEL_HOST}:${REMOTE_PATH}"
